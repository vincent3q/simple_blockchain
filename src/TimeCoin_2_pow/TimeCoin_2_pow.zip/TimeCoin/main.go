// TimeCoin project main.go
package main

import (
	"TimeCoin/block"
	"fmt"
	"strconv"
)

func main() {
	bc := block.NewBlockChain()

	bc.AddBlock("I am the first transaction...")
	bc.AddBlock("Send a timecoin to you... ")

	for _, blk := range bc.Blocks {
		fmt.Printf("Prev hash: %x\n", blk.PrevBlockHash)
		fmt.Printf("Data: %s\n", blk.Data)
		fmt.Printf("Hash: %x\n", blk.Hash)

		pow := block.NewPow(blk)
		fmt.Printf("PoW: %s\n", strconv.FormatBool(pow.Validate()))

		fmt.Println()
	}
}
