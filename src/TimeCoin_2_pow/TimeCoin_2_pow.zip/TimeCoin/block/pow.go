package block

import (
	"TimeCoin/util"
	"bytes"
	"crypto/sha256"
	"fmt"
	"math"
	"math/big"
)

var (
	maxNonce = math.MaxInt64
)

const targetBits = 24

type Pow struct {
	Block  *Block
	Target *big.Int
}

func NewPow(b *Block) *Pow {
	target := big.NewInt(1)
	target.Lsh(target, uint(256-targetBits))

	pow := &Pow{b, target}
	return pow
}

func (p *Pow) Run() (int, []byte) {
	var hashInt big.Int
	var hash [32]byte
	nonce := 0

	fmt.Printf("Mining the block containing %s\n", p.Block.Data)
	for nonce < maxNonce {
		data := p.prepareData(nonce)
		hash = sha256.Sum256(data)
		fmt.Printf("\r%x", hash)
		hashInt.SetBytes(hash[:])

		if hashInt.Cmp(p.Target) == -1 {
			break
		} else {
			nonce++
		}
	}
	fmt.Print("\n\n")

	return nonce, hash[:]
}

func (p *Pow) Validate() bool {
	var hashInt big.Int
	data := p.prepareData(p.Block.Nonce)
	hash := sha256.Sum256(data)

	hashInt.SetBytes(hash[:])

	isValid := hashInt.Cmp(p.Target) == -1

	return isValid
}

func (p *Pow) prepareData(nonce int) []byte {
	data := bytes.Join(
		[][]byte{
			p.Block.PrevBlockHash,
			p.Block.Data,
			util.IntToHex(p.Block.Timestamp),
			util.IntToHex(int64(targetBits)),
			util.IntToHex(int64(nonce)),
		},
		[]byte{},
	)
	return data
}
